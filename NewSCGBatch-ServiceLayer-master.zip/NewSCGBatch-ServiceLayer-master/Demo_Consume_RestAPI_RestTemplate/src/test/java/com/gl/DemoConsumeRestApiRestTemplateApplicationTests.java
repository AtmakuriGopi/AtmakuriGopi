package com.gl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoConsumeRestApiRestTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
