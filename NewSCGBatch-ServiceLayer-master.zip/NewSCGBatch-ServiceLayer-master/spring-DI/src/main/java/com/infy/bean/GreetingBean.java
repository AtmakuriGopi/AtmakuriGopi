package com.infy.bean;

public class GreetingBean {
	
	public String welcome(String name)
	{
		return "Hi "+name+", Welcome to the world of Spring IOC";
	}

}
