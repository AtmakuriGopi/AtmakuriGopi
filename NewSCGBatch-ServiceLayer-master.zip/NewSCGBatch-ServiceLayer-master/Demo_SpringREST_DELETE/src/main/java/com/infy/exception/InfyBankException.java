package com.infy.exception;

//Custom Exception Class
public class InfyBankException extends Exception {

	public InfyBankException(String message) {
		super(message);
		
	}
	
}
